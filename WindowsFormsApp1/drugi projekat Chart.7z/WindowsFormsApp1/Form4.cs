﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System;
using System.Windows.Forms.DataVisualization.Charting;
using System.Data.OleDb;

namespace WindowsFormsApp1
{


    public partial class Form4 : Form
    {

        string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Jovan\\source\\repos\\WindowsFormsApp1\\Restoran.accdb";

        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int idjela = Convert.ToInt32(textBox1.Text);

           DateTime dt  = dateTimePicker1.Value;

            DateTime d2 = dateTimePicker1.Value;



            string query =$"  select * from stavka_racuna where id_Racun in( SELECT id_racun FROM Racun where datum>={dt} and datum<={d2})" ;
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                 
                }
            }





            Series series = new Series("Prodaja jela");



            series.Points.AddXY("Jelo 1", 10);
            series.Points.AddXY("Jelo 2", 20);
            series.Points.AddXY("Jelo 3", 15);

            chart1.Series.Add(series);

            chart1.ChartAreas[0].AxisX.Title = "Jela";
            chart1.ChartAreas[0].AxisY.Title = "Prodaja";





            chart1.Visible = true;

        }
    }
}
