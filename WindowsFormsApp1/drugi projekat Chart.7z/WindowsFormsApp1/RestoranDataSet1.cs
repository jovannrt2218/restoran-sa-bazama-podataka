﻿namespace WindowsFormsApp1
{


    partial class RestoranDataSet
    {
        partial class Stavka_racunaDataTable
        {
        }
    }
}
